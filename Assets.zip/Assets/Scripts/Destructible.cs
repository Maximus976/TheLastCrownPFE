using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class Destructible : MonoBehaviour
{
    [Header("Param�tres de l'objet")]
    public int health = 100; // Points de vie de l'objet
    public int damageOnClick = 25; // D�g�ts inflig�s lorsque l'on clique
    public GameObject destructionEffect; // Effet � jouer lors de la destruction

    // M�thode pour infliger des d�g�ts � l'objet
    public void TakeDamage(int damage)
    {
        health -= damage;
        Debug.Log("D�g�ts re�us : " + damage + " PV restants : " + health);

        if (health <= 0)
        {
            DestroyObject();
        }
    }

    // M�thode pour d�truire l'objet avec une animation
    private void DestroyObject()
    {
        // V�rifie si un effet de destruction est assign�
        if (destructionEffect != null)
        {
            // Instancie l'effet � la position de l'objet
            Instantiate(destructionEffect, transform.position, transform.rotation);
        }

        // D�truit l'objet
        Destroy(gameObject);
        Debug.Log("Objet d�truit !");
    }

    // M�thode appel�e lorsqu'on clique sur l'objet
    private void OnMouseDown()
    {
        TakeDamage(damageOnClick);
    }
}